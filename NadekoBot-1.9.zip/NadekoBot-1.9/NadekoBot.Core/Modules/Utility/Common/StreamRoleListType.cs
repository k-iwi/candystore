﻿namespace NadekoBot.Modules.Utility.Common
{
    public enum StreamRoleListType
    {
        Whitelist,
        Blacklist,
    }
}
