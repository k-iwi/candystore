﻿using System;

namespace NadekoBot.Modules.Gambling.Common.AnimalRacing.Exceptions
{
    public class AnimalRaceFullException : Exception
    {
    }
}
