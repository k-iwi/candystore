﻿namespace NadekoBot.Common.ModuleBehaviors
{
    public interface ILateBlockingExecutor
    {
        
    }
}
